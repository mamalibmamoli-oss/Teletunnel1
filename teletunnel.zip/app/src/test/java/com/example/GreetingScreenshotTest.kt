package com.example

import android.content.Context
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onRoot
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.example.data.AppDatabase
import com.example.data.ProxyEntity
import com.example.data.ProxyRepository
import com.example.data.ProxyType
import com.example.ui.ProxyApp
import com.example.ui.theme.MyApplicationTheme
import com.example.viewmodel.ProxyViewModel
import com.github.takahirom.roborazzi.RobolectricDeviceQualifiers
import com.github.takahirom.roborazzi.captureRoboImage
import kotlinx.coroutines.runBlocking
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import org.robolectric.annotation.GraphicsMode

@RunWith(RobolectricTestRunner::class)
@GraphicsMode(GraphicsMode.Mode.NATIVE)
@Config(qualifiers = RobolectricDeviceQualifiers.Pixel8, sdk = [36])
class GreetingScreenshotTest {

    @get:Rule 
    val composeTestRule = createComposeRule()

    @Test
    fun greeting_screenshot() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        
        // Setup in-memory DB and insert a couple of sample Telegram proxies for screenshot presentation
        val db = Room.inMemoryDatabaseBuilder(context, AppDatabase::class.java)
            .allowMainThreadQueries()
            .build()
        val repository = ProxyRepository(db.proxyDao())
        
        runBlocking {
            repository.insertProxy(
                ProxyEntity(
                    id = 1,
                    name = "پروکسی آلمان (سرعت بالا)",
                    type = ProxyType.MTPROTO,
                    server = "85.214.250.11",
                    port = 443,
                    secret = "dd00112233445566778899aabbccddeeff",
                    isSelected = true
                )
            )
            repository.insertProxy(
                ProxyEntity(
                    id = 2,
                    name = "پروکسی SOCKS5 هلند",
                    type = ProxyType.SOCKS5,
                    server = "194.109.6.93",
                    port = 1080,
                    isSelected = false
                )
            )
        }

        val viewModel = ProxyViewModel(repository)

        composeTestRule.setContent {
            MyApplicationTheme {
                ProxyApp(
                    viewModel = viewModel,
                    onRequestVpnPermission = {}
                )
            }
        }

        composeTestRule.onRoot().captureRoboImage(filePath = "src/test/screenshots/greeting.png")
        
        db.close()
    }
}
