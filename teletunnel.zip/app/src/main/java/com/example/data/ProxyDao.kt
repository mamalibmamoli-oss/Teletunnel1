package com.example.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface ProxyDao {
    @Query("SELECT * FROM proxies ORDER BY id DESC")
    fun getAllProxies(): Flow<List<ProxyEntity>>

    @Query("SELECT * FROM proxies WHERE id = :id LIMIT 1")
    suspend fun getProxyById(id: Long): ProxyEntity?

    @Query("SELECT * FROM proxies WHERE isSelected = 1 LIMIT 1")
    suspend fun getSelectedProxy(): ProxyEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertProxy(proxy: ProxyEntity): Long

    @Update
    suspend fun updateProxy(proxy: ProxyEntity)

    @Query("DELETE FROM proxies WHERE id = :id")
    suspend fun deleteProxy(id: Long)

    @Query("UPDATE proxies SET isSelected = 0")
    suspend fun deselectAll()

    @Query("UPDATE proxies SET isSelected = 1 WHERE id = :id")
    suspend fun selectProxyInternal(id: Long)

    suspend fun selectProxy(id: Long) {
        deselectAll()
        selectProxyInternal(id)
    }
}
