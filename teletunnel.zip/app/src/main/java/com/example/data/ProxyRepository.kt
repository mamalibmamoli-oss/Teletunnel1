package com.example.data

import kotlinx.coroutines.flow.Flow

class ProxyRepository(private val proxyDao: ProxyDao) {
    val allProxies: Flow<List<ProxyEntity>> = proxyDao.getAllProxies()

    suspend fun getProxyById(id: Long): ProxyEntity? {
        return proxyDao.getProxyById(id)
    }

    suspend fun getSelectedProxy(): ProxyEntity? {
        return proxyDao.getSelectedProxy()
    }

    suspend fun insertProxy(proxy: ProxyEntity): Long {
        return proxyDao.insertProxy(proxy)
    }

    suspend fun updateProxy(proxy: ProxyEntity) {
        proxyDao.updateProxy(proxy)
    }

    suspend fun deleteProxy(id: Long) {
        proxyDao.deleteProxy(id)
    }

    suspend fun selectProxy(id: Long) {
        proxyDao.selectProxy(id)
    }

    suspend fun deselectAll() {
        proxyDao.deselectAll()
    }
}
