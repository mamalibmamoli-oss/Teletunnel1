package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

enum class ProxyType {
    SOCKS5,
    HTTP,
    MTPROTO
}

@Entity(tableName = "proxies")
data class ProxyEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val type: ProxyType,
    val server: String,
    val port: Int,
    val username: String? = null,
    val password: String? = null,
    val secret: String? = null, // Used specifically for MTProto
    val isSelected: Boolean = false,
    val latency: Int? = null, // null means untested, -1 means offline, >0 is response time in ms
    val lastTested: Long = 0
)
