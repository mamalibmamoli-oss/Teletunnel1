package com.example

import android.content.Intent
import android.net.VpnService
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.ui.Modifier
import com.example.data.AppDatabase
import com.example.data.ProxyRepository
import com.example.ui.ProxyApp
import com.example.ui.theme.MyApplicationTheme
import com.example.viewmodel.ProxyViewModel
import com.example.viewmodel.ProxyViewModelFactory

class MainActivity : ComponentActivity() {

    private lateinit var viewModel: ProxyViewModel

    // Activity result contract for preparing VpnService
    private val vpnPrepareLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == RESULT_OK) {
            viewModel.startVpn(this)
        } else {
            viewModel.triggerEvent("مجوز اتصال به شبکه VPN تایید نشد")
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        // Request notification permission for Android 13+ to display FGS notification
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            requestPermissions(arrayOf(android.Manifest.permission.POST_NOTIFICATIONS), 101)
        }

        // Setup Room Persistence and DI
        val database = AppDatabase.getDatabase(this)
        val repository = ProxyRepository(database.proxyDao())
        viewModel = ProxyViewModelFactory(repository).create(ProxyViewModel::class.java)

        setContent {
            MyApplicationTheme {
                Scaffold(modifier = Modifier.fillMaxSize()) { innerPadding ->
                    ProxyApp(
                        viewModel = viewModel,
                        onRequestVpnPermission = { requestVpnPermission() },
                        modifier = Modifier.padding(innerPadding)
                    )
                }
            }
        }
    }

    private fun requestVpnPermission() {
        val intent = VpnService.prepare(this)
        if (intent != null) {
            vpnPrepareLauncher.launch(intent)
        } else {
            viewModel.startVpn(this)
        }
    }
}
