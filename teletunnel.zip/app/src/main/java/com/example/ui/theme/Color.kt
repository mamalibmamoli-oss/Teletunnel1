package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Cyberpunk Luxury Dark Theme
val DeepNavy = Color(0xFF0C1020)       // Background
val CardNavy = Color(0xFF151C33)       // Surface card
val BorderNavy = Color(0xFF232D4C)     // Card outlines
val CyberCyan = Color(0xFF00E5FF)      // Primary action / Active VPN
val CyberPurple = Color(0xFFBF5AF2)    // Secondary/Accent
val GlowGreen = Color(0xFF30D158)      // Success / Connected
val PingAmber = Color(0xFFFF9F0A)      // Untested/Medium ping
val ErrorRed = Color(0xFFFF453A)       // Offline / Error
val TextWhite = Color(0xFFFFFFFF)      // Primary text
val TextGray = Color(0xFF8E8E93)       // Supporting text
val TextDark = Color(0xFF1C1C1E)       // Dark contrast text
