package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable

private val DarkColorScheme = darkColorScheme(
    primary = CyberCyan,
    secondary = CyberPurple,
    tertiary = GlowGreen,
    background = DeepNavy,
    surface = CardNavy,
    outline = BorderNavy,
    onPrimary = TextDark,
    onSecondary = TextWhite,
    onBackground = TextWhite,
    onSurface = TextWhite
)

private val LightColorScheme = lightColorScheme(
    primary = CyberCyan,
    secondary = CyberPurple,
    tertiary = GlowGreen,
    background = DeepNavy,
    surface = CardNavy,
    outline = BorderNavy,
    onPrimary = TextDark,
    onSecondary = TextWhite,
    onBackground = TextWhite,
    onSurface = TextWhite
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = false, // Force custom cyberpunk theme for premium unified look
    content: @Composable () -> Unit,
) {
    val colorScheme = if (darkTheme) DarkColorScheme else DarkColorScheme // Force dark aesthetic for Cyberpunk Tunnel client

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
