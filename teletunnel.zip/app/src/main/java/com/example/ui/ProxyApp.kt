package com.example.ui

import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.ContentPaste
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Dns
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.FlashOn
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.filled.Lan
import androidx.compose.material.icons.filled.PowerSettingsNew
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.RadioButton
import androidx.compose.material3.RadioButtonDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.ProxyEntity
import com.example.data.ProxyType
import com.example.service.ProxyVpnService
import com.example.ui.theme.*
import com.example.viewmodel.ProxyViewModel
import kotlinx.coroutines.flow.collectLatest
import java.util.Locale

@Composable
fun ProxyApp(
    viewModel: ProxyViewModel,
    onRequestVpnPermission: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val proxies by viewModel.proxies.collectAsState()
    val vpnState by viewModel.vpnState.collectAsState()
    val activeProxyName by viewModel.activeProxyName.collectAsState()
    val bytesUploaded by viewModel.bytesUploaded.collectAsState()
    val bytesDownloaded by viewModel.bytesDownloaded.collectAsState()
    val durationSeconds by viewModel.durationSeconds.collectAsState()

    var showAddDialog by remember { mutableStateOf(false) }
    var editingProxy by remember { mutableStateOf<ProxyEntity?>(null) }

    // Listen to ViewModel event flows for toasts
    LaunchedEffect(key1 = true) {
        viewModel.eventFlow.collectLatest { message ->
            Toast.makeText(context, message, Toast.LENGTH_SHORT).show()
        }
    }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        containerColor = MaterialTheme.colorScheme.background
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(horizontal = 16.dp, vertical = 8.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // App Header
            AppHeader()

            Spacer(modifier = Modifier.height(16.dp))

            // Main VPN Power Button Dashboard
            VpnPowerDashboard(
                state = vpnState,
                durationSeconds = durationSeconds,
                activeProxyName = activeProxyName,
                onToggleConnection = {
                    if (vpnState == ProxyVpnService.State.CONNECTED) {
                        viewModel.stopVpn(context)
                    } else if (vpnState == ProxyVpnService.State.DISCONNECTED) {
                        onRequestVpnPermission()
                    }
                }
            )

            Spacer(modifier = Modifier.height(16.dp))

            // Live Network Statistics Widgets
            NetworkStatsSection(
                bytesUploaded = bytesUploaded,
                bytesDownloaded = bytesDownloaded
            )

            Spacer(modifier = Modifier.height(20.dp))

            // Action Buttons Bar
            QuickActionToolbar(
                onImportFromClipboard = {
                    val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                    val clipData = clipboard.primaryClip
                    if (clipData != null && clipData.itemCount > 0) {
                        val text = clipData.getItemAt(0).text?.toString() ?: ""
                        if (text.isNotEmpty()) {
                            viewModel.parseAndAddFromLink(text)
                        } else {
                            viewModel.triggerEvent("حافظه موقت خالی است")
                        }
                    } else {
                        viewModel.triggerEvent("حافظه موقت خالی است")
                    }
                },
                onManualAdd = { showAddDialog = true }
            )

            Spacer(modifier = Modifier.height(16.dp))

            // Proxies List Header
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 4.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "لیست پروکسی‌ها (${proxies.size})",
                    color = TextWhite,
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp
                )
                if (proxies.isNotEmpty()) {
                    TextButton(
                        onClick = {
                            proxies.forEach { viewModel.testLatency(it) }
                        }
                    ) {
                        Icon(
                            imageName = Icons.Default.FlashOn,
                            contentDescription = "تست همه",
                            tint = CyberCyan,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("تست سرعت همه", color = CyberCyan, fontSize = 12.sp)
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Proxy List / Empty State
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
            ) {
                if (proxies.isEmpty()) {
                    EmptyProxiesView(onManualAdd = { showAddDialog = true })
                } else {
                    LazyColumn(
                        modifier = Modifier.fillMaxSize(),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        items(proxies, key = { it.id }) { proxy ->
                            ProxyListItem(
                                proxy = proxy,
                                isConnectingOrConnected = vpnState != ProxyVpnService.State.DISCONNECTED,
                                onSelect = { viewModel.selectProxy(proxy.id) },
                                onTestPing = { viewModel.testLatency(proxy) },
                                onDelete = { viewModel.deleteProxy(proxy.id) },
                                onEdit = { editingProxy = proxy }
                            )
                        }
                    }
                }
            }
        }
    }

    // Add / Edit Proxy Dialog
    if (showAddDialog || editingProxy != null) {
        ProxyEditDialog(
            existingProxy = editingProxy,
            onDismiss = {
                showAddDialog = false
                editingProxy = null
            },
            onSave = { proxy ->
                if (editingProxy != null) {
                    viewModel.updateProxy(proxy)
                } else {
                    viewModel.addProxy(proxy)
                }
                showAddDialog = false
                editingProxy = null
            }
        )
    }
}

@Composable
fun AppHeader() {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.Center,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            imageVector = Icons.Default.Lan,
            contentDescription = "TeleTunnel Logo",
            tint = CyberCyan,
            modifier = Modifier.size(24.dp)
        )
        Spacer(modifier = Modifier.width(8.dp))
        Text(
            text = "تله‌تانل (TeleTunnel)",
            color = TextWhite,
            fontSize = 20.sp,
            fontWeight = FontWeight.ExtraBold,
            fontFamily = FontFamily.SansSerif
        )
    }
}

@Composable
fun VpnPowerDashboard(
    state: ProxyVpnService.State,
    durationSeconds: Long,
    activeProxyName: String?,
    onToggleConnection: () -> Unit
) {
    val transition = rememberInfiniteTransition(label = "pulse")
    val pulseScale by transition.animateFloat(
        initialValue = 0.95f,
        targetValue = 1.08f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulseScale"
    )

    val innerGlowAlpha by transition.animateFloat(
        initialValue = 0.2f,
        targetValue = 0.7f,
        animationSpec = infiniteRepeatable(
            animation = tween(1000, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "glowAlpha"
    )

    val ringColor by animateColorAsState(
        targetValue = when (state) {
            ProxyVpnService.State.CONNECTED -> GlowGreen
            ProxyVpnService.State.CONNECTING -> CyberPurple
            ProxyVpnService.State.DISCONNECTED -> CyberCyan
        },
        label = "ringColor"
    )

    val statusText = when (state) {
        ProxyVpnService.State.CONNECTED -> "اتصال برقرار است"
        ProxyVpnService.State.CONNECTING -> "درحال اتصال..."
        ProxyVpnService.State.DISCONNECTED -> "قطع اتصال"
    }

    val formattedTime = remember(durationSeconds) {
        val h = durationSeconds / 3600
        val m = (durationSeconds % 3600) / 60
        val s = durationSeconds % 60
        String.format(Locale.US, "%02d:%02d:%02d", h, m, s)
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .widthIn(max = 500.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(24.dp),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = statusText,
                color = ringColor,
                fontWeight = FontWeight.Bold,
                fontSize = 18.sp,
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = if (state == ProxyVpnService.State.CONNECTED) "مدت زمان اتصال: $formattedTime" else "آماده برای اتصال تانل کل گوشی",
                color = TextGray,
                fontSize = 13.sp,
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(24.dp))

            // Interactive Power Button with Custom Canvas Glow Ring
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier
                    .size(170.dp)
                    .testTag("vpn_toggle_button")
            ) {
                // Outer Pulsating Ring (only when connected/connecting)
                if (state != ProxyVpnService.State.DISCONNECTED) {
                    Canvas(
                        modifier = Modifier
                            .size(160.dp)
                            .scale(pulseScale)
                    ) {
                        drawCircle(
                            color = ringColor,
                            radius = size.minDimension / 2,
                            style = Stroke(width = 2.dp.toPx()),
                            alpha = innerGlowAlpha
                        )
                    }
                }

                // Inner Solid Circle Button
                Box(
                    modifier = Modifier
                        .size(125.dp)
                        .clip(CircleShape)
                        .background(
                            Brush.radialGradient(
                                colors = listOf(
                                    MaterialTheme.colorScheme.surface,
                                    DeepNavy
                                )
                            )
                        )
                        .border(
                            width = 3.dp,
                            brush = Brush.sweepGradient(
                                colors = listOf(ringColor, ringColor.copy(alpha = 0.4f), ringColor)
                            ),
                            shape = CircleShape
                        )
                        .clickable(onClick = onToggleConnection),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.PowerSettingsNew,
                        contentDescription = "کلید اتصال",
                        tint = ringColor,
                        modifier = Modifier.size(52.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Selected Proxy Name Banner
            if (activeProxyName != null) {
                Text(
                    text = "پروکسی فعال: $activeProxyName",
                    color = TextWhite,
                    fontWeight = FontWeight.Medium,
                    fontSize = 14.sp,
                    textAlign = TextAlign.Center,
                    modifier = Modifier
                        .background(
                            color = CyberPurple.copy(alpha = 0.15f),
                            shape = RoundedCornerShape(8.dp)
                        )
                        .padding(horizontal = 14.dp, vertical = 6.dp)
                )
            } else {
                Text(
                    text = "پروکسی فعال جهت تانل کل گوشی مشخص نشده",
                    color = TextGray,
                    fontSize = 12.sp,
                    textAlign = TextAlign.Center
                )
            }
        }
    }
}

@Composable
fun NetworkStatsSection(bytesUploaded: Long, bytesDownloaded: Long) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .widthIn(max = 500.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        val upText = remember(bytesUploaded) { formatBytes(bytesUploaded) }
        val downText = remember(bytesDownloaded) { formatBytes(bytesDownloaded) }

        // Upload Card
        Card(
            modifier = Modifier.weight(1f),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            shape = RoundedCornerShape(16.dp),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(14.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.End
            ) {
                Column(horizontalAlignment = Alignment.End) {
                    Text("آپلود ترافیک", color = TextGray, fontSize = 11.sp)
                    Text(upText, color = CyberCyan, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                }
                Spacer(modifier = Modifier.width(10.dp))
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .background(CyberCyan.copy(alpha = 0.1f), CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.KeyboardArrowUp,
                        contentDescription = "Upload Icon",
                        tint = CyberCyan,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }
        }

        // Download Card
        Card(
            modifier = Modifier.weight(1f),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            shape = RoundedCornerShape(16.dp),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(14.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.End
            ) {
                Column(horizontalAlignment = Alignment.End) {
                    Text("دانلود ترافیک", color = TextGray, fontSize = 11.sp)
                    Text(downText, color = GlowGreen, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                }
                Spacer(modifier = Modifier.width(10.dp))
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .background(GlowGreen.copy(alpha = 0.1f), CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.KeyboardArrowDown,
                        contentDescription = "Download Icon",
                        tint = GlowGreen,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }
        }
    }
}

@Composable
fun QuickActionToolbar(
    onImportFromClipboard: () -> Unit,
    onManualAdd: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .widthIn(max = 500.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Clipboard Quick Import Button
        Button(
            onClick = onImportFromClipboard,
            modifier = Modifier
                .weight(1f)
                .height(48.dp)
                .testTag("import_clipboard_button"),
            colors = ButtonDefaults.buttonColors(containerColor = CyberPurple),
            shape = RoundedCornerShape(14.dp)
        ) {
            Icon(
                imageVector = Icons.Default.ContentPaste,
                contentDescription = "وارد کردن",
                tint = TextWhite,
                modifier = Modifier.size(18.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text("وارد کردن از حافظه", color = TextWhite, fontWeight = FontWeight.Bold, fontSize = 13.sp)
        }

        // Manual Add Button
        Button(
            onClick = onManualAdd,
            modifier = Modifier
                .weight(1f)
                .height(48.dp)
                .testTag("add_proxy_button"),
            colors = ButtonDefaults.buttonColors(containerColor = CyberCyan),
            shape = RoundedCornerShape(14.dp)
        ) {
            Icon(
                imageVector = Icons.Default.Add,
                contentDescription = "افزودن دستی",
                tint = TextDark,
                modifier = Modifier.size(18.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text("افزودن دستی پروکسی", color = TextDark, fontWeight = FontWeight.Bold, fontSize = 13.sp)
        }
    }
}

@Composable
fun ProxyListItem(
    proxy: ProxyEntity,
    isConnectingOrConnected: Boolean,
    onSelect: () -> Unit,
    onTestPing: () -> Unit,
    onDelete: () -> Unit,
    onEdit: () -> Unit
) {
    val isSelected = proxy.isSelected
    val activeBorderColor by animateColorAsState(
        targetValue = if (isSelected) CyberCyan else MaterialTheme.colorScheme.outline,
        label = "borderColor"
    )

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(enabled = !isConnectingOrConnected || !isSelected) { onSelect() },
        colors = CardDefaults.cardColors(
            containerColor = if (isSelected) MaterialTheme.colorScheme.surface else MaterialTheme.colorScheme.surface.copy(alpha = 0.5f)
        ),
        shape = RoundedCornerShape(16.dp),
        border = BorderStroke(1.dp, activeBorderColor)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            // Right Section: Selection Radio and Proxy details (RTL friendly)
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.weight(1f)
            ) {
                RadioButton(
                    selected = isSelected,
                    onClick = { if (!isConnectingOrConnected || !isSelected) onSelect() },
                    colors = RadioButtonDefaults.colors(
                        selectedColor = CyberCyan,
                        unselectedColor = TextGray
                    ),
                    modifier = Modifier.scale(0.9f)
                )

                Spacer(modifier = Modifier.width(4.dp))

                Column(horizontalAlignment = Alignment.Start) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = proxy.name,
                            color = TextWhite,
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Box(
                            modifier = Modifier
                                .background(
                                    color = when (proxy.type) {
                                        ProxyType.SOCKS5 -> CyberCyan.copy(alpha = 0.15f)
                                        ProxyType.HTTP -> CyberPurple.copy(alpha = 0.15f)
                                        ProxyType.MTPROTO -> GlowGreen.copy(alpha = 0.15f)
                                    },
                                    shape = RoundedCornerShape(4.dp)
                                )
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = proxy.type.name,
                                color = when (proxy.type) {
                                    ProxyType.SOCKS5 -> CyberCyan
                                    ProxyType.HTTP -> CyberPurple
                                    ProxyType.MTPROTO -> GlowGreen
                                },
                                fontWeight = FontWeight.Bold,
                                fontSize = 9.sp
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "${proxy.server}:${proxy.port}",
                        color = TextGray,
                        fontSize = 12.sp,
                        textAlign = TextAlign.Left
                    )
                }
            }

            // Left Section: Action Buttons (Ping and Edit/Delete)
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                // Ping status / test
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(MaterialTheme.colorScheme.background)
                        .clickable { onTestPing() }
                        .padding(horizontal = 8.dp, vertical = 6.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center
                    ) {
                        val pingColor = when {
                            proxy.latency == null -> TextGray
                            proxy.latency == -1 -> ErrorRed
                            proxy.latency < 200 -> GlowGreen
                            proxy.latency < 500 -> PingAmber
                            else -> ErrorRed
                        }

                        val pingText = when {
                            proxy.latency == null -> "آزمون"
                            proxy.latency == -1 -> "قطع"
                            else -> "${proxy.latency}ms"
                        }

                        Icon(
                            imageVector = Icons.Default.Speed,
                            contentDescription = "سرعت سنج",
                            tint = pingColor,
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = pingText,
                            color = pingColor,
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp
                        )
                    }
                }

                // Edit Action
                IconButton(onClick = onEdit) {
                    Icon(
                        imageVector = Icons.Default.Edit,
                        contentDescription = "ویرایش",
                        tint = TextGray,
                        modifier = Modifier.size(18.dp)
                    )
                }

                // Delete Action
                IconButton(onClick = onDelete) {
                    Icon(
                        imageVector = Icons.Default.Delete,
                        contentDescription = "حذف",
                        tint = ErrorRed.copy(alpha = 0.8f),
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
        }
    }
}

@Composable
fun EmptyProxiesView(onManualAdd: () -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Icon(
            imageVector = Icons.Default.Dns,
            contentDescription = "No Proxies",
            tint = TextGray.copy(alpha = 0.4f),
            modifier = Modifier.size(72.dp)
        )
        Spacer(modifier = Modifier.height(16.dp))
        Text(
            text = "لیست پروکسی‌های شما خالی است",
            color = TextWhite,
            fontWeight = FontWeight.Bold,
            fontSize = 16.sp,
            textAlign = TextAlign.Center
        )
        Spacer(modifier = Modifier.height(8.dp))
        Text(
            text = "می‌توانید لینک پروکسی تلگرام (MTProto یا SOCKS5) را کپی کرده و بر روی دکمه «وارد کردن از حافظه» بزنید تا خودکار اضافه شود، یا دستی ثبت کنید.",
            color = TextGray,
            fontSize = 12.sp,
            textAlign = TextAlign.Center,
            modifier = Modifier.padding(horizontal = 16.dp)
        )
        Spacer(modifier = Modifier.height(20.dp))
        TextButton(
            onClick = onManualAdd,
            colors = ButtonDefaults.textButtonColors(contentColor = CyberCyan)
        ) {
            Icon(Icons.Default.Add, contentDescription = "اضافه کردن", modifier = Modifier.size(16.dp))
            Spacer(modifier = Modifier.width(4.dp))
            Text("ثبت اولین پروکسی", fontWeight = FontWeight.Bold, fontSize = 14.sp)
        }
    }
}

@Composable
fun ProxyEditDialog(
    existingProxy: ProxyEntity?,
    onDismiss: () -> Unit,
    onSave: (ProxyEntity) -> Unit
) {
    var name by remember { mutableStateOf(existingProxy?.name ?: "") }
    var type by remember { mutableStateOf(existingProxy?.type ?: ProxyType.SOCKS5) }
    var server by remember { mutableStateOf(existingProxy?.server ?: "") }
    var portText by remember { mutableStateOf(existingProxy?.port?.toString() ?: "") }
    var username by remember { mutableStateOf(existingProxy?.username ?: "") }
    var password by remember { mutableStateOf(existingProxy?.password ?: "") }
    var secret by remember { mutableStateOf(existingProxy?.secret ?: "") }

    var errors by remember { mutableStateOf<String?>(null) }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .padding(24.dp)
                .fillMaxWidth()
                .widthIn(max = 450.dp)
                .heightIn(max = 650.dp),
            shape = RoundedCornerShape(24.dp),
            color = CardNavy,
            border = BorderStroke(1.dp, BorderNavy)
        ) {
            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                item {
                    Text(
                        text = if (existingProxy != null) "ویرایش پروکسی" else "افزودن دستی پروکسی جدید",
                        color = TextWhite,
                        fontWeight = FontWeight.Bold,
                        fontSize = 18.sp,
                        textAlign = TextAlign.Center
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "مشخصات پروکسی تلگرام خود را وارد کنید تا کل گوشی تانل شود.",
                        color = TextGray,
                        fontSize = 11.sp,
                        textAlign = TextAlign.Center
                    )
                }

                // Type selector row
                item {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(DeepNavy, RoundedCornerShape(12.dp))
                            .padding(4.dp),
                        horizontalArrangement = Arrangement.SpaceEvenly,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        ProxyType.values().forEach { t ->
                            val isSelectedType = type == t
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(if (isSelectedType) CyberCyan else Color.Transparent)
                                    .clickable { type = t }
                                    .padding(vertical = 8.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = when (t) {
                                        ProxyType.SOCKS5 -> "SOCKS5"
                                        ProxyType.HTTP -> "HTTP"
                                        ProxyType.MTPROTO -> "MTProto"
                                    },
                                    color = if (isSelectedType) TextDark else TextWhite,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 12.sp
                                )
                            }
                        }
                    }
                }

                // Name Input
                item {
                    OutlinedTextField(
                        value = name,
                        onValueChange = { name = it },
                        label = { Text("نام نمایشی پروکسی") },
                        placeholder = { Text("مثلا: سرور آلمان") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        colors = outlinedTextFieldColors()
                    )
                }

                // Server Input
                item {
                    OutlinedTextField(
                        value = server,
                        onValueChange = { server = it },
                        label = { Text("آدرس سرور (IP یا دامنه)") },
                        placeholder = { Text("12.34.56.78") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        colors = outlinedTextFieldColors()
                    )
                }

                // Port Input
                item {
                    OutlinedTextField(
                        value = portText,
                        onValueChange = { portText = it },
                        label = { Text("پورت اتصال") },
                        placeholder = { Text("443") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        colors = outlinedTextFieldColors()
                    )
                }

                // MTProto Secret Input
                if (type == ProxyType.MTPROTO) {
                    item {
                        OutlinedTextField(
                            value = secret,
                            onValueChange = { secret = it },
                            label = { Text("رمز رازپوش (Secret)") },
                            placeholder = { Text("dd001122...") },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true,
                            colors = outlinedTextFieldColors()
                        )
                    }
                } else {
                    // Username and Password Inputs for SOCKS5/HTTP
                    item {
                        OutlinedTextField(
                            value = username,
                            onValueChange = { username = it },
                            label = { Text("نام کاربری (اختیاری)") },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true,
                            colors = outlinedTextFieldColors()
                        )
                    }
                    item {
                        OutlinedTextField(
                            value = password,
                            onValueChange = { password = it },
                            label = { Text("رمز عبور (اختیاری)") },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true,
                            colors = outlinedTextFieldColors()
                        )
                    }
                }

                if (errors != null) {
                    item {
                        Text(
                            text = errors!!,
                            color = ErrorRed,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Medium,
                            textAlign = TextAlign.Center
                        )
                    }
                }

                // Action buttons
                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Button(
                            onClick = {
                                if (server.isBlank() || portText.isBlank()) {
                                    errors = "آدرس سرور و پورت نمی‌توانند خالی باشند"
                                    return@Button
                                }
                                val parsedPort = portText.toIntOrNull()
                                if (parsedPort == null || parsedPort <= 0 || parsedPort > 65535) {
                                    errors = "پورت نامعتبر است (باید بین ۱ تا ۶۵۵۳۵ باشد)"
                                    return@Button
                                }
                                if (type == ProxyType.MTPROTO && secret.isBlank()) {
                                    errors = "برای پروکسی MTProto وارد کردن Secret اجباری است"
                                    return@Button
                                }

                                val finalName = if (name.isBlank()) {
                                    "${type.name} - ${server.take(12)}"
                                } else name

                                val finalProxy = ProxyEntity(
                                    id = existingProxy?.id ?: 0,
                                    name = finalName,
                                    type = type,
                                    server = server.trim(),
                                    port = parsedPort,
                                    username = if (type != ProxyType.MTPROTO && username.isNotBlank()) username.trim() else null,
                                    password = if (type != ProxyType.MTPROTO && password.isNotBlank()) password.trim() else null,
                                    secret = if (type == ProxyType.MTPROTO) secret.trim() else null,
                                    isSelected = existingProxy?.isSelected ?: false,
                                    latency = existingProxy?.latency,
                                    lastTested = existingProxy?.lastTested ?: 0L
                                )
                                onSave(finalProxy)
                            },
                            modifier = Modifier
                                .weight(1f)
                                .height(46.dp)
                                .testTag("dialog_save_button"),
                            colors = ButtonDefaults.buttonColors(containerColor = CyberCyan),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Text("ذخیره پروکسی", color = TextDark, fontWeight = FontWeight.Bold)
                        }

                        TextButton(
                            onClick = onDismiss,
                            modifier = Modifier
                                .weight(0.7f)
                                .height(46.dp),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Text("انصراف", color = TextGray)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun outlinedTextFieldColors() = OutlinedTextFieldDefaults.colors(
    focusedTextColor = TextWhite,
    unfocusedTextColor = TextWhite,
    focusedBorderColor = CyberCyan,
    unfocusedBorderColor = BorderNavy,
    focusedLabelColor = CyberCyan,
    unfocusedLabelColor = TextGray,
    focusedPlaceholderColor = TextGray,
    unfocusedPlaceholderColor = TextGray,
    cursorColor = CyberCyan
)

// Helper function to format bytes nicely
fun formatBytes(bytes: Long): String {
    if (bytes <= 0) return "0 B"
    val units = arrayOf("B", "KB", "MB", "GB", "TB")
    val digitGroups = (Math.log10(bytes.toDouble()) / Math.log10(1024.0)).toInt()
    return String.format(
        Locale.US,
        "%.2f %s",
        bytes / Math.pow(1024.0, digitGroups.toDouble()),
        units[digitGroups]
    )
}

// Inline custom drawing or fallback for older APIs
@Composable
fun BorderStroke(width: androidx.compose.ui.unit.Dp, color: Color) = androidx.compose.foundation.BorderStroke(width, color)

// Backwards-compatible Icon wrapper
@Composable
fun Icon(
    imageName: androidx.compose.ui.graphics.vector.ImageVector,
    contentDescription: String?,
    tint: Color,
    modifier: Modifier = Modifier
) {
    androidx.compose.material3.Icon(
        imageVector = imageName,
        contentDescription = contentDescription,
        tint = tint,
        modifier = modifier
    )
}
