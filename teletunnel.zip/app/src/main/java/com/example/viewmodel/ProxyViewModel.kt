package com.example.viewmodel

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.AppDatabase
import com.example.data.ProxyEntity
import com.example.data.ProxyRepository
import com.example.data.ProxyType
import com.example.service.ProxyVpnService
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.net.InetSocketAddress
import java.net.Socket

class ProxyViewModel(private val repository: ProxyRepository) : ViewModel() {

    private val TAG = "ProxyViewModel"

    // List of all proxies from Room database
    val proxies: StateFlow<List<ProxyEntity>> = repository.allProxies
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    // VPN Service States
    val vpnState: StateFlow<ProxyVpnService.State> = ProxyVpnService.connectionState
    val activeProxyName: StateFlow<String?> = ProxyVpnService.activeProxyName
    val bytesUploaded: StateFlow<Long> = ProxyVpnService.bytesUploaded
    val bytesDownloaded: StateFlow<Long> = ProxyVpnService.bytesDownloaded
    val durationSeconds: StateFlow<Long> = ProxyVpnService.durationSeconds

    // Shared Flow for toast or UI notifications
    private val _eventFlow = MutableSharedFlow<String>()
    val eventFlow: SharedFlow<String> = _eventFlow.asSharedFlow()

    fun triggerEvent(message: String) {
        viewModelScope.launch {
            _eventFlow.emit(message)
        }
    }

    fun startVpn(context: Context) {
        viewModelScope.launch {
            val selected = repository.getSelectedProxy()
            if (selected == null) {
                _eventFlow.emit("لطفاً ابتدا یک پروکسی انتخاب کنید")
                return@launch
            }
            val intent = Intent(context, ProxyVpnService::class.java).apply {
                action = ProxyVpnService.ACTION_CONNECT
            }
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }
    }

    fun stopVpn(context: Context) {
        val intent = Intent(context, ProxyVpnService::class.java).apply {
            action = ProxyVpnService.ACTION_DISCONNECT
        }
        context.startService(intent)
    }

    fun selectProxy(id: Long) {
        viewModelScope.launch {
            repository.selectProxy(id)
        }
    }

    fun addProxy(proxy: ProxyEntity) {
        viewModelScope.launch {
            repository.insertProxy(proxy)
            _eventFlow.emit("پروکسی جدید با موفقیت اضافه شد")
        }
    }

    fun updateProxy(proxy: ProxyEntity) {
        viewModelScope.launch {
            repository.updateProxy(proxy)
            _eventFlow.emit("پروکسی بروزرسانی شد")
        }
    }

    fun deleteProxy(id: Long) {
        viewModelScope.launch {
            repository.deleteProxy(id)
            _eventFlow.emit("پروکسی حذف شد")
        }
    }

    fun testLatency(proxy: ProxyEntity) {
        viewModelScope.launch {
            // Update UI/Entity with intermediate "testing" status
            val testingProxy = proxy.copy(latency = null)
            repository.updateProxy(testingProxy)

            val latencyResult = withContext(Dispatchers.IO) {
                val startTime = System.currentTimeMillis()
                try {
                    val socket = Socket()
                    socket.connect(InetSocketAddress(proxy.server, proxy.port), 2500) // 2.5s timeout
                    socket.close()
                    (System.currentTimeMillis() - startTime).toInt()
                } catch (e: Exception) {
                    Log.w(TAG, "Ping failed to ${proxy.server}:${proxy.port}: ${e.message}")
                    -1
                }
            }

            val updatedProxy = proxy.copy(
                latency = latencyResult,
                lastTested = System.currentTimeMillis()
            )
            repository.updateProxy(updatedProxy)
        }
    }

    fun parseAndAddFromLink(link: String) {
        val parsed = parseProxyUrl(link)
        if (parsed != null) {
            addProxy(parsed)
        } else {
            viewModelScope.launch {
                _eventFlow.emit("فرمت لینک پروکسی نامعتبر است")
            }
        }
    }

    private fun parseProxyUrl(url: String): ProxyEntity? {
        val cleanUrl = url.trim()
        try {
            if (cleanUrl.startsWith("tg://proxy") || cleanUrl.contains("/proxy?")) {
                // MTProto Link (tg://proxy?server=...&port=...&secret=...)
                val uri = Uri.parse(cleanUrl)
                val server = uri.getQueryParameter("server") ?: return null
                val portStr = uri.getQueryParameter("port") ?: return null
                val secret = uri.getQueryParameter("secret") ?: return null
                return ProxyEntity(
                    name = "MTProto " + server.take(12),
                    type = ProxyType.MTPROTO,
                    server = server,
                    port = portStr.toIntOrNull() ?: return null,
                    secret = secret
                )
            } else if (cleanUrl.startsWith("tg://socks") || cleanUrl.contains("/socks?")) {
                // Telegram SOCKS5 Link (tg://socks?server=...&port=...&user=...&pass=...)
                val uri = Uri.parse(cleanUrl)
                val server = uri.getQueryParameter("server") ?: return null
                val portStr = uri.getQueryParameter("port") ?: return null
                val user = uri.getQueryParameter("user")
                val pass = uri.getQueryParameter("pass")
                return ProxyEntity(
                    name = "SOCKS5 " + server.take(12),
                    type = ProxyType.SOCKS5,
                    server = server,
                    port = portStr.toIntOrNull() ?: return null,
                    username = user,
                    password = pass
                )
            } else if (cleanUrl.startsWith("socks5://")) {
                // SOCKS5 standard link
                val cleanStr = cleanUrl.removePrefix("socks5://")
                val atIndex = cleanStr.indexOf('@')
                if (atIndex != -1) {
                    val credentials = cleanStr.substring(0, atIndex).split(":")
                    val address = cleanStr.substring(atIndex + 1).split(":")
                    val user = credentials.getOrNull(0)
                    val pass = credentials.getOrNull(1)
                    val server = address.getOrNull(0) ?: return null
                    val portStr = address.getOrNull(1) ?: return null
                    return ProxyEntity(
                        name = "SOCKS5 " + server.take(12),
                        type = ProxyType.SOCKS5,
                        server = server,
                        port = portStr.toIntOrNull() ?: return null,
                        username = user,
                        password = pass
                    )
                } else {
                    val parts = cleanStr.split(":")
                    val server = parts.getOrNull(0) ?: return null
                    val portStr = parts.getOrNull(1) ?: return null
                    return ProxyEntity(
                        name = "SOCKS5 " + server.take(12),
                        type = ProxyType.SOCKS5,
                        server = server,
                        port = portStr.toIntOrNull() ?: return null
                    )
                }
            } else if (cleanUrl.startsWith("http://") || cleanUrl.startsWith("https://")) {
                // Try checking if it's an HTTP proxy
                val uri = Uri.parse(cleanUrl)
                val host = uri.host ?: return null
                val portVal = if (uri.port != -1) uri.port else 8080
                val userInfo = uri.userInfo
                val (user, pass) = if (userInfo != null) {
                    val idx = userInfo.indexOf(':')
                    if (idx != -1) {
                        Pair(userInfo.substring(0, idx), userInfo.substring(idx + 1))
                    } else {
                        Pair(userInfo, null)
                    }
                } else Pair(null, null)

                return ProxyEntity(
                    name = "HTTP " + host.take(12),
                    type = ProxyType.HTTP,
                    server = host,
                    port = portVal,
                    username = user,
                    password = pass
                )
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error parsing proxy url: ${e.message}", e)
        }
        return null
    }
}

class ProxyViewModelFactory(private val repository: ProxyRepository) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(ProxyViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return ProxyViewModel(repository) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
