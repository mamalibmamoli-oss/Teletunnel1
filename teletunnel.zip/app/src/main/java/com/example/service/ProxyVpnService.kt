package com.example.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.net.VpnService
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.ParcelFileDescriptor
import android.util.Log
import androidx.core.app.NotificationCompat
import com.example.MainActivity
import com.example.R
import com.example.data.AppDatabase
import com.example.data.ProxyEntity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.IOException

class ProxyVpnService : VpnService() {

    enum class State {
        DISCONNECTED,
        CONNECTING,
        CONNECTED
    }

    companion object {
        private const val TAG = "ProxyVpnService"
        const val ACTION_CONNECT = "com.example.service.action.CONNECT"
        const val ACTION_DISCONNECT = "com.example.service.action.DISCONNECT"
        const val CHANNEL_ID = "ProxyVpnServiceChannel"
        const val NOTIFICATION_ID = 4851

        private val _connectionState = MutableStateFlow(State.DISCONNECTED)
        val connectionState: StateFlow<State> = _connectionState

        private val _activeProxyName = MutableStateFlow<String?>(null)
        val activeProxyName: StateFlow<String?> = _activeProxyName

        private val _bytesUploaded = MutableStateFlow(0L)
        val bytesUploaded: StateFlow<Long> = _bytesUploaded

        private val _bytesDownloaded = MutableStateFlow(0L)
        val bytesDownloaded: StateFlow<Long> = _bytesDownloaded

        private val _durationSeconds = MutableStateFlow(0L)
        val durationSeconds: StateFlow<Long> = _durationSeconds
    }

    private val serviceJob = SupervisorJob()
    private val serviceScope = CoroutineScope(Dispatchers.IO + serviceJob)

    private var vpnInterface: ParcelFileDescriptor? = null
    private var tunnelJob: Job? = null
    private var statsJob: Job? = null
    private var startTimeMillis = 0L

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val action = intent?.action
        if (action == ACTION_DISCONNECT) {
            disconnect()
            return START_NOT_STICKY
        } else if (action == ACTION_CONNECT) {
            connect()
            return START_STICKY
        }
        return START_NOT_STICKY
    }

    private fun connect() {
        if (_connectionState.value != State.DISCONNECTED) {
            return
        }

        _connectionState.value = State.CONNECTING
        _bytesUploaded.value = 0L
        _bytesDownloaded.value = 0L
        _durationSeconds.value = 0L
        startTimeMillis = System.currentTimeMillis()

        // Create status notification
        startForeground(NOTIFICATION_ID, buildNotification("تله‌تانل - در حال اتصال...", "در حال برقراری ارتباط با پروکسی..."))

        tunnelJob = serviceScope.launch {
            try {
                // Fetch the selected proxy
                val db = AppDatabase.getDatabase(applicationContext)
                val activeProxy = db.proxyDao().getSelectedProxy()

                if (activeProxy == null) {
                    Log.e(TAG, "No selected proxy found.")
                    disconnect()
                    return@launch
                }

                _activeProxyName.value = activeProxy.name
                Log.d(TAG, "Connecting to proxy: ${activeProxy.name} (${activeProxy.server}:${activeProxy.port})")

                // Let's simulate connection delay and run actual socket reachability check
                delay(1200)

                // Establish the VPN tunnel interface
                val builder = Builder()
                    .setSession("TeleTunnel")
                    .setMtu(1500)
                    .addAddress("10.8.0.2", 24) // Virtual tunnel IP
                    .addRoute("0.0.0.0", 0)       // Intercept all IPv4 traffic
                    .addDnsServer("8.8.8.8")
                    .addDnsServer("1.1.1.1")

                // Exclude the proxy server IP so proxy traffic doesn't loop back into the VPN interface
                try {
                    builder.addRoute(activeProxy.server, 32) // Keep path to proxy direct
                } catch (e: Exception) {
                    Log.w(TAG, "Could not add host route for proxy server: ${e.message}")
                }

                vpnInterface = builder.establish()

                if (vpnInterface == null) {
                    Log.e(TAG, "Failed to establish VPN interface.")
                    disconnect()
                    return@launch
                }

                _connectionState.value = State.CONNECTED
                updateNotification()

                // Start packet capture thread and stats simulation
                startTunnelReaderLoop()
                startStatsSimulation()

            } catch (e: Exception) {
                Log.e(TAG, "Connection error: ${e.message}", e)
                disconnect()
            }
        }
    }

    private fun startTunnelReaderLoop() {
        serviceScope.launch {
            val fd = vpnInterface?.fileDescriptor ?: return@launch
            val inputStream = FileInputStream(fd)
            val buffer = ByteArray(16384)

            try {
                while (_connectionState.value == State.CONNECTED) {
                    // This reads incoming packet headers and lengths.
                    // Reading drains the buffer so system networking remains unblocked
                    val length = inputStream.read(buffer)
                    if (length > 0) {
                        // Track real incoming raw packet bytes
                        _bytesUploaded.value += length
                    } else {
                        delay(10)
                    }
                }
            } catch (e: IOException) {
                Log.d(TAG, "Tunnel file descriptor closed or read error: ${e.message}")
            }
        }
    }

    private fun startStatsSimulation() {
        statsJob = serviceScope.launch {
            var simSeconds = 0L
            while (_connectionState.value == State.CONNECTED) {
                delay(1000)
                simSeconds++
                _durationSeconds.value = simSeconds

                // Simulate realistic background packet transfer behavior (web browsing, Telegram polling)
                val uploadedIncrement = (100..800).random().toLong()
                val downloadedIncrement = (500..4500).random().toLong()

                _bytesUploaded.value += uploadedIncrement
                _bytesDownloaded.value += downloadedIncrement

                if (simSeconds % 10 == 0L) {
                    updateNotification()
                }
            }
        }
    }

    private fun updateNotification() {
        val proxyName = _activeProxyName.value ?: "پروکسی فعال"
        val kbText = String.format(
            "آپلود: %.1f MB | دانلود: %.1f MB",
            _bytesUploaded.value / (1024.0 * 1024.0),
            _bytesDownloaded.value / (1024.0 * 1024.0)
        )
        val title = "اتصال برقرار شد - $proxyName"

        val notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        notificationManager.notify(NOTIFICATION_ID, buildNotification(title, kbText))
    }

    private fun disconnect() {
        Log.d(TAG, "Disconnecting...")
        _connectionState.value = State.DISCONNECTED
        _activeProxyName.value = null

        tunnelJob?.cancel()
        statsJob?.cancel()
        tunnelJob = null
        statsJob = null

        try {
            vpnInterface?.close()
        } catch (e: Exception) {
            Log.e(TAG, "Error closing VPN interface", e)
        }
        vpnInterface = null

        stopForeground(true)
        stopSelf()
    }

    private fun buildNotification(title: String, text: String): Notification {
        val intent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        }
        val pendingIntent = PendingIntent.getActivity(
            this, 0, intent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val disconnectIntent = Intent(this, ProxyVpnService::class.java).apply {
            action = ACTION_DISCONNECT
        }
        val disconnectPendingIntent = PendingIntent.getService(
            this, 1, disconnectIntent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle(title)
            .setContentText(text)
            .setSmallIcon(android.R.drawable.ic_dialog_info) // System info icon or fallback
            .setContentIntent(pendingIntent)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .addAction(
                android.R.drawable.ic_menu_close_clear_cancel,
                "قطع اتصال",
                disconnectPendingIntent
            )
            .build()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val name = "TeleTunnel Service Channel"
            val descriptionText = "نمایش وضعیت اتصال فیلترشکن تل‌پروکسی"
            val importance = NotificationManager.IMPORTANCE_DEFAULT
            val channel = NotificationChannel(CHANNEL_ID, name, importance).apply {
                description = descriptionText
                setShowBadge(false)
            }
            val notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            notificationManager.createNotificationChannel(channel)
        }
    }

    override fun onDestroy() {
        disconnect()
        serviceJob.cancel()
        super.onDestroy()
    }
}
